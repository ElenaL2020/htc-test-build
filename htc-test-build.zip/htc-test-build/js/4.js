if(/MSIE \d|Trident.*rv:/.test(navigator.userAgent))
        document.write('Недопустимо использование данного сайта в Internet Explorer');